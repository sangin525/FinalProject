package kr.co.project.chef.model.service;

import kr.co.project.chef.model.dto.ChefDTO;
import kr.co.project.member.model.dto.MemberDTO;

public interface ChefService {
	
//	public int selectMember(MemberDTO member);

	public int registerChef(int mno);
	
	
	
}
