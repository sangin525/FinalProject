package kr.co.project.order.model.service;

import kr.co.project.order.model.dto.OrderDTO;

public interface OrderService {

	int insertOrder(OrderDTO order);

}
