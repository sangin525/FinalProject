package kr.co.project.order.model.service;

import kr.co.project.order.model.dto.OrderDetailDTO;

public interface OrderDetailService {

	int insertOrderDetail(OrderDetailDTO orderDetail);

}
